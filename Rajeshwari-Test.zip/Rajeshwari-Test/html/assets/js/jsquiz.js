(function() {
  var questions = [{
    question: "your most important expectation from a life insurance company is...",
    choices: ['Competitive Pricing', 'Easy Online Access', 'Dealing directly with Company representatives', 'Hassle free claims process', 'Easy Documentation', 'Sales representative should be highly expertise'],
    correctAnswer: 2
  }, {
    question: "Besides protection, the purpose of Life insurance in your investment portfolio is...",
    choices: ['Helps in saving tax', 'High Policy Term Long Term coverage of policy', 'Adequate savings for life goals / retirement needs'],
    correctAnswer: 3
  }, {
    question: "your most preferred financial product is...",
    choices: ['Life insurance - ULIP Where money is invested in stock market', 'Health Insurance', 'Life insurance - Traditional savings, endowment, money back', 'Bank Fixed Deposits', 'Bank Fixed Deposits'],
    correctAnswer: 5
  }, {
    question: "before finalizing Life Insurance policy purchase, You...",
    choices: ['Consulted a financial advisor', 'Spoke to an agent/broker', 'Consulted friends/family', 'Explored Aggregator sites like Policy Bazaar, Bank Bazaar', 'Researched on Social Media Facebook / Twitter'],
    correctAnswer: 5
  }, {
    question: "Researched on Social Media Facebook / Twitter",
    choices: ['I have planned my investments with future goals in mind', 'I live in present and don’t think too much about future', 'I need to be ahead of competition in life', 'I am content with my life'],
    correctAnswer: 3
  }, {
    question: "your priorities in life...",
    choices: ['Establishing myself at work / in business', 'Taking care of my key future needs like childs education/marriage', 'Improving my standard of living', 'Financial security for my parents other family members'],
    correctAnswer: 2
  }, 
  
  {
    question: "your outlook towards Money is...",
    choices: ['Money is a means to enjoy life', 'Credit card leads me to overspend', 'Borrowing money makes me feel uncomfortable'],
    correctAnswer: 3
  },
  
  {
    question: "You spend maximum time on...",
    choices: ['Television', 'Internet', 'Newspaper/ Magazines'],
    correctAnswer: 1
  }];
  
  var questionCounter = 0; //Tracks question number
  var selections = []; //Array containing user choices
  var quiz = $('#quiz'); //Quiz div object
  
  // Display initial question
  displayNext();
  
  // Click handler for the 'next' button
  $('#next').on('click', function (e) {
    e.preventDefault();
    
    // Suspend click listener during fade animation
    if(quiz.is(':animated')) {        
      return false;
    }
    choose();
    
    // If no user selection, progress is stopped
    if (isNaN(selections[questionCounter])) {
      alert('Please make a selection!');
    } else {
      questionCounter++;
	     guyMove(".guy", questionCounter);

      displayNext();
    }
  });
  
  // Click handler for the 'prev' button
  $('#prev').on('click', function (e) {
    e.preventDefault();
    
    if(quiz.is(':animated')) {
      return false;
    }
    choose();
    questionCounter--;
  guyMove(".guy", questionCounter);  
  displayNext();
  });
  
  // Click handler for the 'Start Over' button
  $('#start').on('click', function (e) {
    e.preventDefault();
    
    if(quiz.is(':animated')) {
      return false;
    }
    questionCounter = 0;
	  guyMove(".guy", questionCounter);
    selections = [];
    displayNext();
    $('#start').hide();
  });
  
  // Animates buttons on hover
  $('.button').on('mouseenter', function () {
    $(this).addClass('active');
  });
  $('.button').on('mouseleave', function () {
    $(this).removeClass('active');
  });
  
  // Creates and returns the div that contains the questions and 
  // the answer selections
  function createQuestionElement(index) {
    var qElement = $('<div>', {
      id: 'question'
    });
    
    var header = $('<h2>Question ' + (index + 1) + ':</h2>');
    qElement.append(header);
    
    var question = $('<h1>').append(questions[index].question);
    qElement.append(question);
    
    var radioButtons = createRadios(index);
    qElement.append(radioButtons);
    
    return qElement;
  }
  
  // Creates a list of the answer choices as radio inputs
  function createRadios(index) {
    var radioList = $('<div>');
    var item;
    var input = '';
    for (var i = 0; i < questions[index].choices.length; i++) {
      item = $('<div class="radiobtn">');
input = '<input type="radio" name="answer" value=' + i + ' id='+ i + ' />';	  
	  input += '<label for='+ i + '>' + questions[index].choices[i] +' </label>';
      
     
      item.append(input);	  
      radioList.append(item);
    }
	
    return radioList;
	
	
  }
  
  
  
  
  // Reads the user selection and pushes the value to an array
  function choose() {
    selections[questionCounter] = +$('input[name="answer"]:checked').val();
	
  }
  
  // Displays next requested element
  function displayNext() {
    quiz.fadeOut(function() {
      $('#question').remove();
      
      if(questionCounter < questions.length){
        var nextQuestion = createQuestionElement(questionCounter);
        quiz.append(nextQuestion).fadeIn();
        if (!(isNaN(selections[questionCounter]))) {
          $('input[value='+selections[questionCounter]+']').prop('checked', true);
		  
        }
        
        // Controls display of 'prev' button
        if(questionCounter === 1){
          $('#prev').show();
        } else if(questionCounter === 0){
          
          $('#prev').hide();
          $('#next').show();
        }
      }else {
        var scoreElem = displayScore();
        quiz.append(scoreElem).fadeIn();
        $('#next').hide();
        $('#prev').hide();
        $('#start').show();
      }
    });
  }
  
  function guyMove(obj, index){
quesCount = questions.length;  
console.log('index'+index);
console.log('quesCount'+quesCount);
console.log('obj'+obj);

  let percent = ((index/quesCount)*100);
  console.log('percent'+percent);
    if (percent<=100){
		console.log('percent innnn '+percent);
		console.log({left:percent+"%"}, 100);
        $(obj).animate({left:percent+"%"}, 100);
    }
}

  
  // Computes score and returns a paragraph element to be displayed
  function displayScore() {
    var score = $('<h2>',{id: 'question'});
    
    var numCorrect = 0;
    for (var i = 0; i < selections.length; i++) {
      if (selections[i] === questions[i].correctAnswer) {
        numCorrect++;
      }
    }$(".buttons, .track, .flagMan").hide();
    
    score.append('youre almost there  Result' );
    return score;
	
	
  }
})();